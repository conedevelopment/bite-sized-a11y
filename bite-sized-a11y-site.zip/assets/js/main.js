(function () {
    console.log('Main script is loaded...')
}());
